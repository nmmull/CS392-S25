use std::str::Lines;
use crate::syntax::Token;

const SYMBOLS : [(&str, Token); 2] =
    [
	("(", Token::Lparen),
	(")", Token::Rparen),
    ];

const KEYWORDS : [(&str, Token); 3] =
    [
	("lambda", Token::Lambda),
	("FUN", Token::FunTy),
	("EMPTY", Token::EmptyTy),
    ];

impl Token {
    fn lexeme(&self) -> &str {
	match self {
	    Token::Lparen => "(",
	    Token::Rparen => ")",
	    Token::Lambda => "lambda",
	    Token::FunTy => "FUN",
	    Token::EmptyTy => "EMPTY",
	    Token::Var(x) => &x,
	}
    }

    fn len(&self) -> usize {
	self.lexeme().len()
    }

    fn is_variable_char(c: char) -> bool {
	c.is_ascii_lowercase()
    }
}

pub struct Lexer<'a> {
    contents: Lines<'a>,
    curr_line: &'a str,
}

impl<'a> Lexer<'a> {
    pub fn new(input: &'a str) -> Lexer<'a> {
	let mut lexer = Lexer {
	    contents: input.lines(),
	    curr_line: ""
	};
	lexer.trim_start();
	lexer
    }

    fn trim_start(&mut self) {
	self.curr_line = self.curr_line.trim_start();
	while self.curr_line.is_empty() {
	    match self.contents.next() {
		Some(line) => {
		    self.curr_line = line.trim_start();
		}
		None => {
		    self.curr_line = "";
		    break
		}
	    }
	}
    }

    fn consume(&mut self, n: usize) {
	if n > self.curr_line.len() {
	    self.curr_line = "";
	    self.trim_start();
	}
	self.curr_line = &self.curr_line[n..];
	self.trim_start();
    }

    fn peek_symbol(&self) -> Option<Token> {
	for (lexeme, token) in SYMBOLS {
	    if self.curr_line.starts_with(lexeme) {
		return Some(token)
	    }
	}
	None
    }

    pub fn peek_keyword(&self) -> Option<Token> {
	for (lexeme, token) in KEYWORDS {
	    if self.curr_line.starts_with(lexeme) {
		return Some(token)
	    }
	}
	None
    }

    fn peek_variable(&self) -> Option<Token> {
	let word_len = self.curr_line
	    .find(|c : char| !Token::is_variable_char(c))
	    .unwrap_or(self.curr_line.len());
	if word_len > 0 {
	    Some(Token::Var(String::from(&self.curr_line[..word_len])))
	} else {
	    None
	}
    }

    fn peek(&self) -> Option<Token> {
	self.peek_symbol()
	    .or_else(|| self.peek_keyword())
	    .or_else(|| self.peek_variable())
    }

    pub fn next(&mut self) -> Option<Token> {
	self.peek()
	    .and_then(|t| {
		self.consume(t.len());
		Some(t)
	    })
    }
}
