use crate::syntax::{Token, Expr, Type};
use crate::lexer::Lexer;

pub struct Parser<'a> {
    lexer: Lexer<'a>,
}

impl<'a> Parser<'a> {
    pub fn new(input: &'a str) -> Parser<'a> {
	Parser {
	    lexer: Lexer::new(input),
	}
    }

    fn parse_type(&mut self) -> Option<Type> {
	match self.lexer.next()? {
	    Token::EmptyTy => {
		Some(Type::Empty)
	    }
	    Token::Lparen => {
		match self.lexer.peek_keyword() {
		    Some(Token::FunTy) => {
			let _fun = self.lexer.next()?;
			let ty1 = self.parse_type()?;
			let ty2 = self.parse_type()?;
			let rparen = self.lexer.next()?;
			match rparen {
			    Token::Rparen => Some(Type::arrow(ty1, ty2)),
			    _ => None,
			}
		    }
		    _ => None,
		}
	    }
	    _ => None,
	}
    }

    fn parse_expr(&mut self) -> Option<Expr> {
	match self.lexer.next()? {
	    Token::Var(s) => {
		Some(Expr::Var(s))
	    }
	    Token::Lparen => {
		match self.lexer.peek_keyword() {
		    Some(Token::Lambda) => {
			let _lambda = self.lexer.next()?;
			let var = self.lexer.next()?;
			let ty = self.parse_type()?;
			let body = self.parse_expr()?;
			let rparen = self.lexer.next()?;
			match (var, rparen) {
			    (Token::Var(x), Token::Rparen) => Some(Expr::lam(&x, ty, body)),
			    _ => None,
			}
		    }
		    _ => {
			let e1 = self.parse_expr()?;
			let e2 = self.parse_expr()?;
			let rparen = self.lexer.next()?;
			match rparen {
			    Token::Rparen => Some(Expr::app(e1, e2)),
			    _ => None,
			}
		    },
		}
	    }
	    _ => None,
	}
    }

    pub fn parse(&mut self) -> Option<Expr> {
	self.parse_expr()
	    .and_then(|e| {
		if self.lexer.next().is_none() {
		    Some(e)
		} else {
		    None
		}
	    })
    }
}
