use crate::syntax::Expr;
use crate::syntax::Ident;
use std::collections::HashMap;
use crate::syntax::Type;

type Context<'a> = HashMap<&'a Ident, &'a Type>;

impl Expr {
    pub fn rename(&mut self) {
	#[derive(Default)]
	struct Rename {
	    names: HashMap<Ident, Ident>,
	    count: i32,
	}

	impl Rename {
	    fn call(&mut self, e: &mut Expr) {
		match e {
		    Expr::Var(x) => {
			if let Some(y) = self.names.get(x) {
			    *x = y.clone();
			}
		    },
		    Expr::App(e1, e2) => {
			self.call(e1);
			self.call(e2);
		    }
		    Expr::Lam(x, _, e) => {
			let s = self.count.to_string();
			self.names.insert(x.clone(), s.clone());
			self.count += 1;
			self.call(e);
			self.names.remove(x);
			*x = s;
		    }
		}
	    }
	}

	Rename::default().call(self);
    }

    // Implement `ty` so that `e.ty(true)` is the type of `e` if it is
    // linearly well-typed and `e.ty(false)` is the type of `e` if it
    // is just well-typed.  You should assume that `e` has been
    // alpha-renamed to have distinct bound variables
    pub fn ty(&self, linear: bool) -> Option<Type> {
	todo!()
    }
}
