use std::fmt;
use std::fmt::Display;

pub type Ident = String;

#[derive(Debug, Clone)]
pub enum Token {
    Lparen,
    Rparen,
    Lambda,
    FunTy,
    EmptyTy,
    Var(String),
}

#[derive(PartialEq, Clone, Debug)]
pub enum Type {
    Empty,
    Arrow(Box<Type>, Box<Type>),
}

impl Type {
    pub fn arrow(t1: Type, t2: Type) -> Type {
	Type::Arrow(Box::new(t1), Box::new(t2))
    }
}

impl Display for Type {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
	match self {
	    Type::Empty => write!(f, "⊥"),
	    Type::Arrow(t1, t2) => write!(f, "({} → {})", t1, t2),
	}
    }
}

#[derive(Debug, Clone)]
pub enum Expr {
    Var(Ident),
    App(Box<Expr>, Box<Expr>),
    Lam(Ident, Type, Box<Expr>),
}

impl Expr {
    pub fn var(x: &str) -> Expr { Expr::Var(String::from(x)) }

    pub fn app(e1: Expr, e2: Expr) -> Expr {
	Expr::App(Box::new(e1), Box::new(e2))
    }

    pub fn lam(x: &str, ty: Type, e: Expr) -> Expr {
	Expr::Lam(String::from(x), ty, Box::new(e))
    }
}

impl Display for Expr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
	match self {
	    Expr::Var(x) => write!(f, "{}", x),
	    Expr::App(e1, e2) => write!(f, "({} {})", e1, e2),
	    Expr::Lam(x, ty, e) => write!(f, "(λ ({} : {}) {})", x, ty, e),
	}
    }
}
