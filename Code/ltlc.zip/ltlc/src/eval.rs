use crate::syntax::Ident;
use crate::syntax::Expr;

impl Expr {
    // Implment `eval` so that `e.eval(true)` returns the result of
    // evaluating `e` assuming it is linearly well-typed and
    // `e.eval(false)` returns the result of evaluating `e` assuming
    // `e` is just well-typed
    //
    // Hint: This will mean implementing a substitution function,
    // likely two, one "normal" and one linear
    pub fn eval(self, linear: bool) -> Expr {
	todo!()
    }
}
