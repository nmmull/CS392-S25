use std::env;
use std::fs::File;
use std::io::Read;
use std::io::{Error, ErrorKind};
use ltlc::parser::Parser;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let filename = {
	let mut args = env::args();
	args.next();
	args.next().ok_or(Error::new(ErrorKind::NotFound, "usage: cargo run <filename>"))?
    };
    let mut file = File::open(filename)?;
    let mut contents = String::new();
    file.read_to_string(&mut contents)?;
    let mut parser = Parser::new(&contents[..]);
    let mut e = parser.parse().ok_or(Error::new(ErrorKind::Other, "Parse error"))?;
    println!("       expr: {}", e);
    if let Some(ty) = e.ty(true) {
	println!("linear type: {}", ty);
	println!("      value: {}", e.eval(true));
    } else if let Some(ty) = e.ty(false) {
	println!("simple type: {}", ty);
	println!("      value: {}", e.eval(false));
    } else {
	println!("             Ill-typed!")
    }
    Ok(())
}
