#![allow(dead_code, unused_variables, unused_mut)]

use std::env;
use std::iter::{zip, repeat_n};
use std::fs::File;
use std::io::{BufReader, BufRead, Lines, Error, ErrorKind};
use std::cmp::max;

// Besides CS320 (Principle of PL), I also often teach CS132, our
// linear algebra course at BUCS.  In this problem, we'll be building
// an interface for working with large sparse matrices, culminating in
// a toy implementation of the power method for probability
// matrices/vectors (which can be used to determine steady states of
// Markov chains with sparse transition matrices)

// An `EdgeList` is an iterator for files in (a simplified version of)
// edge list format:
//
//     + If a line starts with '#' then it is a `Comment`
//
//     + Otherwise, if the first two whitespace-separated strings on a
//       line can be parsed as `usize`s, then the line represents an `Edge`
//
//     + Otherwise, the line represents an `Error`
//
// See small_graph.txt for a basic example
//
// In implementation, an edge list is a newtype wrapper for a line
// reader for a file
struct EdgeList(Lines<BufReader<File>>);

// According to the above specification, each line in an edge list is
// one of these three values

enum EdgeListResult {
    Edge(usize, usize),
    Comment,
    Error
}

// PART 1
// ======
//
// Implement the iterator trait for `EdgeList`.  This will mean using
// the underlying line iterator and transforming the line according to
// the above specification.
impl Iterator for EdgeList {
    type Item = EdgeListResult;

    fn next(&mut self) -> Option<EdgeListResult> {
	todo!()
    }
}

// A Compressed Sparse Row (CSR) matrix is representation for a matrix
// which stores:
//
//     + num_rows:  the number of rows
//
//     + num_cols:  the number of columns
//
//     + data:      the nonzero entries
//
//     + indices:   the COLUMN indices of each nonzero entry
//
//     + ind_ptr:   a list of pointers which describes which column
//                  indices correspond to which rows
//
// The column indices of row i are stored in the range:
//
//     ind_ptr[i]..ind_ptr[i + 1]
//
// EXAMPLE:
//
//     CSRMatrix {
//       num_rows:  3,
//       num_cols:  3,
//       data:      vec![1., 2., 3., 4., 5., 6.],
//       indices:   vec![0,  2,  2,  0,  1,  2],
//       ind_ptr:   vec![0,      2,  3,      6],
//     }
//
// represents the matrix:
//
//     [ 1  0  2 ]
//     [ 0  0  3 ]
//     [ 4  5  6 ]
//
// for more details and examples:
// https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csr_matrix.html

#[derive(Debug)]
struct CSRMatrix {
    num_rows: usize,
    num_cols: usize,
    data: Vec<f64>,
    indices: Vec<usize>,
    ind_ptr: Vec<usize>,
}

// You should look this implementation of the `TryFrom` trait for
// CSRMatrix to get a sense of what it does, but you DO NOT need to
// udpate any of the given code.  The function `try_from` constructs
// an adjacency matrix:
//
//    A[i, j] = 1       if (i, j) is an edge
//    A[i, j] = 0       otherwise
//
// and fails if it finds an `Error` line in the `EdgeList`.
impl TryFrom<EdgeList> for CSRMatrix {
    type Error = std::io::Error;

    fn try_from(edge_list : EdgeList) -> Result<CSRMatrix, Error> {
	let mut num_verts = 0;
	let mut curr_row = 0;
	let mut ind_ptr = vec![0];
	let mut indices = vec![];
	for e in edge_list {
	    if let EdgeListResult::Edge(row, col) = e {
		num_verts = max(num_verts, max(row, col));
		if row > curr_row {
		    for _ in 0..(row - curr_row) {
			ind_ptr.push(indices.len());
		    }
		    curr_row = row;
		}
		indices.push(col);
	    } else if let EdgeListResult::Error = e {
		return Err(Error::new(
		    ErrorKind::InvalidData,
		    "ill-formed edge list",
		))
	    }
	}
	num_verts += 1;
	for _ in ind_ptr.len()..num_verts + 1 {
	    ind_ptr.push(indices.len());
	}
	let data = repeat_n(1.0, indices.len()).collect();
	Ok(CSRMatrix {
	    num_rows: num_verts,
	    num_cols: num_verts,
	    ind_ptr,
	    indices,
	    data
	})
    }
}

// PART 2
// ======
//
// A single row can be represented by the following structure, which
// has references to slices of the `data` and `indices` of a given
// matrix.  It also keeps track of the row number, i.e., which row of
// the underlying matrix it is.  Explain the role of the lifetime
// parameters in this structure.
//
// EXPLANATION: TODO

// #[derive(Debug)]
struct Row<'a> {
    num: usize,
    indices: &'a [usize],
    data: &'a [f64],
}

// PART 3
// ======
//
// Implement a `Row` iterator. You should use the `curr` field to keep
// track which row needs to be returned by the method `next` below
#[derive(Debug)]
struct Rows<'a> {
    curr: usize,
    matrix: &'a CSRMatrix,
}

// The `next` function should construct a new `Row` for every row in
// `self`. In particular, it should use the `ind_ptr` field to grab
// the appropriate slice of `data` and `indices` for a given row.
impl<'a> Iterator for Rows<'a> {
    type Item = Row<'a>;

    fn next(&mut self) -> Option<Self::Item> {
	todo!();
    }
}

// a structure for mutable rows
#[derive(Debug)]
struct RowMut<'a> {
    num: usize,
    indices: &'a mut [usize],
    data: &'a mut [f64],
}

impl CSRMatrix {
    // makes a `Row` iterator for `self`
    fn rows(&self) -> Rows {
	Rows {
	    curr: 0,
	    matrix: self,
	}
    }

    // makes a `RowMut` for the `n`th row of `self`
    fn row_mut<'a>(&'a mut self, n: usize) -> RowMut<'a> {
 	let start = self.ind_ptr[n];
 	let end = self.ind_ptr[n + 1];
	RowMut {
	    num: n,
	    indices: &mut self.indices[start..end],
	    data: &mut self.data[start..end],
	}
    }

    // makes the l1-norm of every nonzero row 1
    fn normalize_rows(&mut self) {
	for i in 0..self.num_rows {
	    let curr_row = self.row_mut(i);
	    let sum : f64 = curr_row.data
		.as_ref()
		.into_iter()
		.sum();
	    curr_row.data
		.into_iter()
		.for_each(|v| *v /= sum);
	}
    }

    // PART 4 (Extra Credit)
    // =====================
    //
    // Implement left vector-matrix multiplication, i.e.,
    //
    // v.T @ self
    //
    // in NumPy syntax.
    //
    // Hints:
    //
    // + Keep in mind that CRSMatrices keep track of ROWS, not
    //   columns
    //
    // + Use the row iterator you just built
    //
    // + Consider using zip to create a simultanous iterator of
    //   `indices` and `data`
    fn mul_vec_left(&self, v: &Vec<f64>) -> Vec<f64> {
	todo!();
    }

    // adds two matrices, mutably updating `self`
    fn add(&mut self, a: CSRMatrix) {
	let mut indices: Vec<usize> = vec![];
	let mut data: Vec<f64> = vec![];
	let mut ind_ptr: Vec<usize> = vec![0];
	for (r1, r2) in zip(self.rows(), a.rows()) {
	    let mut i1 = 0; let mut i2 = 0;
	    while i1 < r1.indices.len() && i2 < r2.indices.len() {
		if r1.indices[i1] < r2.indices[i2] {
		    indices.push(r1.indices[i1]);
		    data.push(r1.data[i1]);
		    i1 += 1;
		} else if r1.indices[i1] > r2.indices[i2] {
		    indices.push(r2.indices[i2]);
		    data.push(r2.data[i2]);
		    i2 += 1;
		} else {
		    indices.push(r1.indices[i1]);
		    data.push(r1.data[i1] + r2.data[i2]);
		    i1 += 1; i2 += 1;
		}
	    }
	    if i1 < r1.indices.len() {
		indices.extend(&r1.indices[i1..]);
		data.extend(&r1.data[i1..]);
	    } else if i2 < r2.indices.len() {
		indices.extend(&r2.indices[i2..]);
		data.extend(&r2.data[i2..]);
	    }
	    ind_ptr.push(data.len());
	}
	*self = CSRMatrix {
	    num_rows: self.num_rows,
	    num_cols: self.num_cols,
	    data,
	    indices,
	    ind_ptr,
	}
    }

    // identity matrix
    fn id(n: usize) -> CSRMatrix {
	CSRMatrix {
	    num_rows: n,
	    num_cols: n,
	    data: repeat_n(1.0, n).collect(),
	    indices: (0..n).collect(),
	    ind_ptr: (0..n + 1).collect(),
	}
    }

    // This implementation of the power method assumes `self` and `v`
    // are probability matrices/vectors
    fn pow_method_prob(&self, v: &mut Vec<f64>, n: usize) {
	for _ in 0..n {
	    *v = self.mul_vec_left(v);
	}
    }
}

// PART 5
// ======
//
// It's natural to want to build a `RowMut` iterator in analogy with
// `Rows`.
struct RowsMut<'a> {
    curr: usize,
    matrix: &'a mut CSRMatrix,
}

// But if you take your `Iterator` implementation for `Rows` and
// update it minimally to make it work for `RowsMut`, you'll likely
// get an error like this (you should try it yourself too!):
//
// error: lifetime may not live long enough
//     |
//     | impl<'a> Iterator for RowsMut<'a> {
//     |      -- lifetime `'a` defined here
// ...
//     |     fn next(&mut self) -> Option<Self::Item> {
//     |             - let's call the lifetime of this reference `'1`
// ...
//     |     return Some(row);
//     |            ^^^^^^^^^ method was supposed to return data with lifetime `'a` but it is returning data with lifetime `'1`
//
// Explain why it makes sense to get a error in this scenario. (You
// don't need to explain the error itself, though you're welcome to if
// you'd like)
//
// EXPLANATION: TODO


// I've included a very small test graph for the above code, but
// you can also grab a web graph from:
//
// https://snap.stanford.edu/data/#web
//
// if you want to try your solution on something more substantial
fn main() -> std::io::Result<()> {
    // get a file name at the command line and open it
    let args : Vec<String> = env::args().collect();
    let filename = args.get(1).ok_or(
	Error::new(ErrorKind::NotFound, "USAGE: cargo run <filename>")
    )?;
    let file = File::open(filename)?;

    // POSSIBLE AFTER PART 1
    //
    // construct a matrix from an edge list
    println!("loading matrix...");
    let mut adj_mat = CSRMatrix::try_from(EdgeList(BufReader::new(file).lines()))?;

    // POSSIBLE AFTER PART 2 & 3
    //
    // add the identity to ensure no empty rows
    // (not the most elegant, but it works)
    // then normalize rows
    println!("preprocessing matrix...");
    adj_mat.add(CSRMatrix::id(adj_mat.num_rows));
    adj_mat.normalize_rows();

    // uniform distribution
    let mut v : Vec<f64> = std::iter::repeat_n(
	1.0 / (adj_mat.num_rows as f64),
	adj_mat.num_rows,
    ).collect();

    // POSSIBLE AFTER PART 4
    println!("power method...");
    for _ in 0..10 {
	const NUM: usize = 10;
	println!("taking {NUM} steps...");
	adj_mat.pow_method_prob(&mut v, NUM);
	let max_entry = v
            .iter()
            .enumerate()
            .max_by(|(_, a), (_, b)| a.total_cmp(b))
	    .unwrap();
	println!("largest entry:  v[{}] = {}", max_entry.0, max_entry.1);
	println!("      l1-norm:  {}", v.iter().sum::<f64>());
    }
    Ok(())
}
