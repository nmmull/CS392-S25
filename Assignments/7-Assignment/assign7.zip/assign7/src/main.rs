use std::env;
use std::fs::File;
use std::io::Read;
use std::io::{Error, ErrorKind};
use assign7::parser::Parser;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let filename = {
	let mut args = env::args();
	args.next();
	args.next().ok_or(Error::new(ErrorKind::NotFound, "USAGE: cargo run <filename>"))?
    };
    let mut file = File::open(filename)?;
    let mut contents = String::new();
    file.read_to_string(&mut contents)?;
    let mut parser = Parser::new(&contents[..]);
    let e = parser.parse().ok_or(Error::new(ErrorKind::Other, "parse error"))?;
    e.ty().ok_or(Error::new(ErrorKind::Other, "type error"))?;
    println!("{}", e.eval());
    Ok(())
}
