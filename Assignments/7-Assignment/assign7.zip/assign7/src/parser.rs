use std::iter::Peekable;
use crate::syntax::{Expr, Type};
use crate::lexer::{Lexer, Token};

pub struct Parser<'a> {
    lexer: Peekable<Lexer<'a>>,
}

type ParseResult<T> = Option<T>;

impl<'a> Parser<'a> {
    pub fn new(input: &'a str) -> Parser<'a> {
	Parser {
	    lexer: Lexer::new(input).peekable(),
	}
    }

    fn next_token(&mut self) -> ParseResult<Token> {
	self.lexer.next()?
    }

    fn peek_token(&mut self) -> ParseResult<&Token> {
	let token = self.lexer.peek();
	match token {
	    Some(Some(token)) => Some(token),
	    _ => None
	}
    }


    // `parse_type` should parse a type off the front of the contents
    // of self.lexer if possible. Note that it is okay for the parser
    // to consume part of the input if it fails (we will not need to
    // deal with backtracking)
    fn parse_type(&mut self) -> Option<Type> {
	todo!()
    }

    // same as above, but for expressions. Take a look at the code
    // from lecture as well as the grammar. Also, make sure to use
    // `next_token` and `peek_token`!
    fn parse_expr(&mut self) -> Option<Expr> {
	todo!()
    }

    pub fn parse(&mut self) -> Option<Expr> {
	self.parse_expr()
	    .and_then(|e| {
		if self.lexer.next().is_none() {
		    Some(e)
		} else {
		    None
		}
	    })
    }
}
