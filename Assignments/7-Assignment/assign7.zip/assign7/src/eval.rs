use crate::syntax::Ident;
use crate::syntax::Expr;

impl Expr {
    // `e.subst(v, x)` should mutably update `e` so that `x` is
    // substituted in `v`. It should return `Some v` if `x` does not
    // appear in `e` and `None` otherwise.
    fn subst(&mut self, e: Expr, x: &Ident) -> Option<Expr> {
	todo!();
    }

    // You should use the above substitution function to implement
    // the semantics of LTLC
    pub fn eval(self) -> Expr {
	todo!()
    }
}
