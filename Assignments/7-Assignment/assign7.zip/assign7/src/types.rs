use crate::syntax::Expr;
use crate::syntax::Ident;
use crate::syntax::Type;

impl Expr {
    // `e.ty` is the linear type of `e` (note that we're don't have
    // the `linear` flag as we did in lecture)
    pub fn ty(&self) -> Option<Type> {
	todo!()
    }
}
