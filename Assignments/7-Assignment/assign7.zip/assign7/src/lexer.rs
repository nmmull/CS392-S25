use std::str::Lines;

#[derive(Debug, Clone)]
pub enum Token {
    Lparen,
    Rparen,
    Let,
    Lambda,
    FunTy,
    EmptyTy,
    Var(String),
}

const SYMBOLS : [(&str, Token); 2] =
    [
	("(", Token::Lparen),
	(")", Token::Rparen),
    ];

const KEYWORDS : [(&str, Token); 3] =
    [
	("lambda", Token::Lambda),
	("FUN", Token::FunTy),
	("EMPTY", Token::EmptyTy),
    ];

impl Token {
    fn is_variable_char(c: char) -> bool {
	c.is_ascii_lowercase() || c == '_'
    }

    fn variable(s: &str) -> Token {
	Token::Var(String::from(s))
    }
}

type LexResult = Option<Token>;

pub struct Lexer<'a> {
    contents: Lines<'a>,
    curr_line: &'a str,
}

impl<'a> Lexer<'a> {
    pub fn new(input: &'a str) -> Lexer<'a> {
	let mut lexer = Lexer {
	    contents: input.lines(),
	    curr_line: ""
	};
	lexer.trim_start();
	lexer
    }

    fn done(&self) -> bool {
	self.curr_line.is_empty()
    }

    fn trim_start(&mut self) {
	self.curr_line = self.curr_line.trim_start();
	while self.curr_line.is_empty() {
	    match self.contents.next() {
		Some(line) => {
		    self.curr_line = line.trim_start();
		}
		None => {
		    self.curr_line = "";
		    break
		}
	    }
	}
    }

    fn consume(&mut self, n: usize) {
	if n > self.curr_line.len() {
	    self.curr_line = "";
	    self.trim_start();
	}
	self.curr_line = &self.curr_line[n..];
	self.trim_start();
    }

    fn token(token: Token) -> LexResult {
	Some(token)
    }

    fn error() -> LexResult {
	None
    }

    fn symbol(&mut self) -> LexResult {
	for (lexeme, token) in SYMBOLS {
	    if self.curr_line.starts_with(lexeme) {
		self.consume(lexeme.len());
		return Lexer::token(token)
	    }
	}
	Lexer::error()
    }

    fn keyword(&mut self) -> LexResult {
	for (lexeme, token) in KEYWORDS {
	    if self.curr_line.starts_with(lexeme) {
		self.consume(lexeme.len());
		return Lexer::token(token)
	    }
	}
	Lexer::error()
    }

    fn variable(&mut self) -> LexResult {
	let len = self.curr_line
	    .find(|c: char| !Token::is_variable_char(c))
	    .unwrap_or(self.curr_line.len());
	if len > 0 {
	    let out = Token::variable(&self.curr_line[..len]);
	    self.consume(len);
	    return Lexer::token(out)
	}
	Lexer::error()
    }
}

impl<'a> Iterator for Lexer<'a> {
    type Item = LexResult;

    fn next(&mut self) -> Option<LexResult> {
	if self.done() {
	    None
	} else {
	    Some(
		self.symbol()
		    .or_else(|| self.keyword())
		    .or_else(|| self.variable())
	    )
	}
    }
}
